SQLALCHEMY_DATABASE_URI = 'postgresql://vcm:dbpasswd@localhost/beers'
SQLALCHEMY_ECHO = True
DEBUG = True
